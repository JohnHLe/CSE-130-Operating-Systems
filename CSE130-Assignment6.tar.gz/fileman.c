/*********************************************************************
 *
 * Copyright (C) 2020-2021 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 *
 ***********************************************************************/

#include "fileman.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <fcntl.h> 

/*
 * You need to implement this function, see fileman.h for details 
 */
int fileman_read(char *fname, size_t foffset, char *buf, size_t boffset, size_t size) {
	int fd_readf;
	if( (fd_readf= open(fname, O_RDONLY)) == -1) return -1; // file failed to open or signal interrupt 
	lseek(fd_readf, foffset, SEEK_CUR); // reposition file
	int num_bytes = read(fd_readf, buf + boffset, size);	
	close(fd_readf);
	return num_bytes;
}

/*
 * You need to implement this function, see fileman.h for details 
 */
int fileman_write(char *fname, size_t foffset, char *buf, size_t boffset, size_t size) {
	// int fd_created = open(fname, O_CREAT | O_WRONLY, 00700); 
	int fd_created = creat(fname, O_RDONLY | 00777); 
	if(fd_created == -1 || fd_created == 4) return -1; // if error in creating 
	lseek(fd_created, foffset, SEEK_CUR);
	int num_bytes = write(fd_created, buf + boffset, size); // return Number of bytes written on success 
	close(fd_created);
	return num_bytes;
}

/*
 * You need to implement this function, see fileman.h for details 
 */
int fileman_append(char *fname, char *buf, size_t size) {
	int fd_read = open(fname, O_WRONLY);
	if(fd_read == -1) return -1; // file does not exist
	lseek(fd_read, 0, SEEK_END);
	int num_bytes = write(fd_read,buf, size);
	close(fd_read);
	return num_bytes;
}

/*
 * You need to implement this function, see fileman.h for details 
 */
int fileman_copy(char *fsrc, char *fdest) {
	FILE *fd_frsrc, *fd_fdest; 
	fd_frsrc = fopen(fsrc, "r");
	if(fd_frsrc == NULL ) return -1; 
	fd_fdest = fopen(fdest, "w");
	if(fd_fdest == NULL ) return -1;  
	// while loop fputc/fgetc to copy the fsrc to fdest
	//  is based on https://www.geeksforgeeks.org/c-program-copy-contents-one-file-another-file/
	char c = fgetc(fd_frsrc);
	while(c != EOF) {
		fputc(c, fd_fdest);
		c = fgetc(fd_frsrc);
	}
	int size = ftell(fd_fdest);
	fclose(fd_frsrc);
	fclose(fd_fdest);
	return size;
}
int depth = 1;

/*
 * You need to implement this function, see fileman.h for details 
 */
 // listing the files in all directories implementation on:
 // https://codeforwin.org/2018/03/c-program-to-list-all-files-in-a-directory-recursively.html#program
void fileman_dir(int fd, char *dname) { // dname is data.dir
	struct dirent **ptr; 
	DIR *dp = opendir(dname);
	if(dp == NULL) return; 
	int directD = scandir(dname, &ptr, NULL, alphasort); 
	int stored = directD;
	if (directD == -1) return; 
	int k = 0;

	if(strcmp(dname, "data.dir") == 0){
		char first[100];
		strcpy(first, dname);
		strcat(first, "\n");
		write(fd, first, strlen(first));
	}
	while(directD--) { 
		if (strcmp(ptr[k]->d_name, ".") != 0 && strcmp(ptr[k]->d_name, "..") != 0){
			for(int i = 0; i < depth; ++i) {
				write(fd, "    ", strlen("    "));
			}
			char temp[100];
			strcpy(temp, ptr[k]->d_name);
			strcat(temp, "\n");
			write(fd, temp, strlen(temp));
			
			char path[100];
			strcpy(path, dname);
            strcat(path, "/");
            strcat(path, ptr[k]->d_name);
			++depth;
			fileman_dir(fd, path); // recursive call 
			--depth;
		}
		k++;
	}
	for(int i = 0; i < stored; ++i) 
		free(ptr[i]);
	
	free(ptr);
	closedir(dp);
}

/*
 * You need to implement this function, see fileman.h for details 
 */
void fileman_tree(int fd, char *dname) {
}

