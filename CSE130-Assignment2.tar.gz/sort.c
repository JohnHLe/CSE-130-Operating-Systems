#include "merge.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* LEFT index and RIGHT index of the sub-array of ARR[] to be sorted */
void singleThreadedMergeSort(int arr[], int left, int right) 
{
  if (left < right) {
    int middle = (left+right)/2;
    singleThreadedMergeSort(arr, left, middle); 
    singleThreadedMergeSort(arr, middle+1, right); 
    merge(arr, left, middle, right); 
  } 
}

typedef struct Quarter {
  int leftt, rightt;
  int *tarr; // thread array 
} Quarter;

typedef struct Half {
  int leftt, rightt, middle;
  int *marr; // merge array 
} Half;

void *sort_helper(void * arg) {
  Quarter* quart = (Quarter*) arg; 
  singleThreadedMergeSort(quart->tarr, quart->leftt, quart->rightt);
  pthread_exit(NULL);
  
}
void *merge_helper(void* arg) {
  Half* half = (Half*) arg;
  merge(half->marr, half->leftt, half->middle, half->rightt); 
  pthread_exit(NULL);
}

/* 
 * This function stub needs to be completed
 */
void multiThreadedMergeSort(int arr[], int left, int right) 
{
  // Your code goes here 
  // create 4 threads
  // destroy threads when finished 
  // each thread merge sort 1/4 of the array, join threads
  // merge quarters
  
  const int num_threads = 3; 
  int length = right - left;  
  int middle = (length / 2) + left; 
  pthread_t threadd[num_threads]; // thread ID 

  // thread 0, sort first quarter
  Quarter quart1; 
  quart1.tarr = arr;
  quart1.leftt = left; 
  quart1.rightt = left + (length / 4);
  int test = pthread_create(&threadd[0], NULL, sort_helper, &quart1);
  if(test == -1 ) { 
    exit(-1); // thread was not created
  }

  // thread 1, sort second quarter
  Quarter quart2; 
  quart2.tarr = arr;
  quart2.leftt = quart1.rightt + 1; 
  quart2.rightt = middle;
  test = pthread_create(&threadd[1], NULL, sort_helper, &quart2);
  if(test == -1 ) { 
    exit(-1); // thread was not created
  }
  // thread 2, sort third quarter
  Quarter quart3; 
  quart3.tarr = arr;
  quart3.leftt = middle + 1;
  quart3.rightt = quart3.leftt + (length / 4);
  test = pthread_create(&threadd[2], NULL, sort_helper, &quart3);
  if(test == -1 ) { 
    exit(-1); // thread was not created
  }
  // thread 3, sort last quarter
  Quarter quart4; 
  quart4.tarr = arr;
  quart4.leftt = quart3.rightt + 1; 
  quart4.rightt = right;
  test = pthread_create(&threadd[3], NULL, sort_helper, &quart4);
  if(test == -1 ) { 
    exit(-1); // thread was not created
  }

  // join threads back together 
  for(int i = 0; i < num_threads; ++i) { 
    pthread_join(threadd[i], NULL); 
  }

  // Merge  
  // thread 0, Merge Left Half
  Half half1;
  half1.marr = arr; 
  half1.leftt = left; 
  half1.middle = left + (length / 4);
  half1.rightt = middle;
  int merging = pthread_create(&threadd[0], NULL, merge_helper, &half1);
  if(merging == -1 ) { 
    exit(-1); // thread was not created
  }

  // thread 1, Merge Right Half
  Half half2;
  half2.marr = arr;
  half2.leftt = middle + 1; 
  half2.middle = middle + (length / 4) + 1;
  half2.rightt = right;
  merging = pthread_create(&threadd[1], NULL, merge_helper, &half2);
  if(merging == -1 ) { 
    exit(-1); // thread was not created
  }
  // join threads back together 
  for(int i = 0; i < 2; ++i) { 
    pthread_join(threadd[i], NULL); 
  }

  // thread 2, Merge Both Halves
  half2.marr = arr;
  half2.leftt = left; 
  half2.middle = middle;
  half2.rightt = right;
  merging = pthread_create(&threadd[2], NULL, merge_helper, &half2);
  if(merging == -1) { 
    exit(-1); // thread was not created
  }
  // join thread back together 
  pthread_join(threadd[2], NULL); 
}