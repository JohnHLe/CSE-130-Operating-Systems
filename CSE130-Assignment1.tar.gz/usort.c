/************************************************************************
 * 
 * CSE130 Winter 2021 Assignment 1
 * 
 * UNIX Shared Memory Multi-Process Merge Sort
 * 
 * Copyright (C) 2020-2021 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 *
 ************************************************************************/

#include "merge.h"
#include <sys/ipc.h> 
#include <sys/shm.h>
#include <sys/wait.h> 
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* LEFT index and RIGHT index of the sub-array of ARR[] to be sorted */
void singleProcessMergeSort(int arr[], int left, int right) 
{
  if (left < right) {
    int middle = (left+right)/2;
    singleProcessMergeSort(arr, left, middle); 
    singleProcessMergeSort(arr, middle+1, right); 
    merge(arr, left, middle, right); 
  } 
}

/* 
 * This function stub needs to be completed
 */
void multiProcessMergeSort(int arr[], int left, int right) 
{
  // Your code goes here
  if (left < right) {
    int shmid = shmget(IPC_PRIVATE, 1024, 0666|IPC_CREAT); // put into shared memory 
    int *shm = (int*) shmat(shmid, (void*)0,0); 
    int middle = (left+right) / 2;
    int half = middle - left + 1; // return half of num of arr elem
    // const int SIZE = sizeof(&arr);
    // put array into shared memory
    // for(int i = left; i <= right; ++i) { 
    //   shm[i] = arr[i]; 
    // } 
    memcpy(shm, arr, half * sizeof(int)); 
    switch(fork()) {
      case -1:
        exit(-1); 
      case 0: //child process  
        singleProcessMergeSort(shm, left, middle); // sort to shared memory 
        shmdt(shm); // detach out of shared memory
        exit(0); 
      default: //parent process 
        singleProcessMergeSort(arr, middle+1, right); 
        wait(NULL); // block parent process until any of its children has finished. 

        // put reinsert the shared memory portion into original array
        // for(int i = left; i <= middle; ++i) {
        //   arr[i] = shm[i]; 
        // }
        memcpy(arr, shm, half * sizeof(int)); 
        merge(arr, left, middle, right); 
        shmdt(shm);// detach from shared memory segment
        shmctl(shmid, IPC_RMID, NULL); // destroy shared memory segment 
    }
    shmctl(shmid, IPC_RMID, NULL); // detach from shared memory segment 
  } 
}