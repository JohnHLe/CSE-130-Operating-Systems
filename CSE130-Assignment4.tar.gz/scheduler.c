/**
 * See scheduler.h for function details. All are callbacks; i.e. the simulator 
 * calls you when something interesting happens.
 */
#include <stdlib.h>
#include <stdio.h>
// #include <stdbool.h>
#include "simulator.h"
#include "scheduler.h"
typedef enum {false, true} bool;
struct threadInfo { 
  thread_t *threadd; // holds thread 

  int first_tick; // first tick of the wait time 
  int last_tick; // last tick of the wait time

  int arrival_time; // time thread arrived 
  int exit_time; // time thread exited the program 
  
  int turnaround_time; // turnaround time
  int cpu_wait_time; // time it takes to get back on cpu from io and arrival 
  int io_wait_time; // time it takes to start io
};

// Queue Implementation based on https://www.geeksforgeeks.org/queue-linked-list-implementation/
// I took createNode(), enqueue(), dequeue() from the implementation
struct Node { 
  struct threadInfo *data; 
  struct Node *next; 
};

struct Node* createNode(struct threadInfo* info){ // constructor 
  struct Node *n = (struct Node*)malloc(sizeof(struct Node)); // allocates mem
  n->data = info;
  n->next = NULL; 
  return n; 
}

struct Queue { 
  struct Node *front;
  struct Node *end; 
  int count;
};

void enQueue(struct Queue *q, struct threadInfo* info ) { 
  struct Node *n = createNode(info); 
  q->count++;
  if(q->end == NULL) {
    q->front = n = q->end = n; // c
    return;
  } 
  q->end->next = n;
  q->end = q->end->next;
}

// I made this isEmpty function 
bool isEmpty(struct Queue* q) {
  if(q->front == NULL) 
    return true;
  else 
    return false; 
}

void deQueue(struct Queue* q) { 
  if(q->front != NULL) {
    q->count--;
    struct Node* n = q->front; 
    q->front = q->front->next;
    if(q->front == NULL)
      q->end = NULL;
    free(n); 
  }
  return;
}
// Queue Implementation based on https://www.geeksforgeeks.org/queue-linked-list-implementation/
// Queue Implementation end

// I made this find thread function
struct threadInfo* findThread(struct Queue* q, thread_t *t) {
  printf("Hit\n");
  struct Node* iterator = q->front; 
  if(iterator == NULL){
    return NULL;
  }
  while(iterator->data->threadd->tid != t->tid){
    iterator = iterator->next;
  }
  return iterator->data; 
}

struct Queue *ready_queue; // threads ready to go on cpu 
struct Queue *everything_queue; // all threads 

thread_t* running_thread = NULL;

void scheduler(enum algorithm algorithm, unsigned int quantum) {
  ready_queue = (struct Queue*)malloc(sizeof(struct Queue));
  everything_queue = (struct Queue*)malloc(sizeof(struct Queue));
}

void sim_tick() {}

void sys_exec(thread_t *t) {
  // printf("exec\n");
  struct threadInfo *info = (struct threadInfo*)malloc(sizeof(struct threadInfo));
  info->arrival_time = sim_time();
  info->exit_time = 0; 
  info->first_tick = 0;
  info->last_tick = 0;
  info->exit_time = 0; // end tick, use sim_time() at exit() ? 
  info->turnaround_time = 0;
  info->cpu_wait_time = 0; // time it takes to get on cpu|
  info->io_wait_time = 0; // time it takes to get on io
  
  // if nothing on the cpu, dispatch 
  // else put into ready queue
  if(running_thread == NULL){
    running_thread = t;
    info->threadd = running_thread; 
    info->cpu_wait_time = sim_time() - info->arrival_time;
    info->last_tick = sim_time() + 1;
    enQueue(everything_queue, info); // temp
    // enQueue(ready_queue, info); // added
    sim_dispatch(t);
  }
  else {
    info->threadd = t; 
    info->first_tick = sim_time();
    enQueue(everything_queue, info); // temp
    enQueue(ready_queue, info); 
  }
}
 // enqueue IO
void sys_read(thread_t *t) {
  printf("read\n");
  findThread(everything_queue, running_thread)->last_tick = sim_time();
  // ready_queue->front->data->last_tick = sim_time();
  running_thread = NULL;
  // deQueue(ready_queue);
  if(running_thread == NULL && !isEmpty(ready_queue)) {
    running_thread = ready_queue->front->data->threadd;
    ready_queue->front->data->last_tick = sim_time() + 1;
    struct threadInfo * info =  ready_queue->front->data;
    info->cpu_wait_time += sim_time() - info->first_tick + 1;

    deQueue(ready_queue);
    sim_dispatch(running_thread); // dispatch next ready thread 
  }
}

void sys_write(thread_t *t) {
  printf("write\n");
  findThread(everything_queue, running_thread)->last_tick = sim_time();
  // ready_queue->front->data->last_tick = sim_time();
  running_thread = NULL;
  // deQueue(ready_queue);
  if(running_thread == NULL && !isEmpty(ready_queue)) {
    running_thread = ready_queue->front->data->threadd;
    ready_queue->front->data->last_tick = sim_time() + 1;
    struct threadInfo * info =  ready_queue->front->data;
    info->cpu_wait_time += sim_time() - info->first_tick + 1;
  
    deQueue(ready_queue);
    sim_dispatch(running_thread); // dispatch next ready thread 
  }
}

// thread ends here
void sys_exit(thread_t *t) {
  // printf("exit\n");
  // struct threadInfo *info = ready_queue->front->data;
  struct threadInfo *info = findThread(everything_queue, running_thread);
  printf("PID: %d\n", info->threadd->tid);
  // info->last_tick = sim_time();
  info->exit_time = sim_time(); 
  info->turnaround_time = info->exit_time - info->arrival_time + 1; 
  running_thread = NULL;

  // enQueue(everything_queue, info);
  // deQueue(ready_queue); // added
  if(running_thread == NULL && !isEmpty(ready_queue)) {
    running_thread = ready_queue->front->data->threadd;
    ready_queue->front->data->cpu_wait_time += sim_time() - ready_queue->front->data->first_tick + 1;
    // printf("CPU TIME: %d\n", info->cpu_wait_time);
    deQueue(ready_queue);
    sim_dispatch(running_thread); // dispatch next ready thread 
  }
}

void io_complete(thread_t *t) {
  printf("IOcomplete\n");
  struct threadInfo *info = findThread(everything_queue, t);

  info->first_tick = sim_time() + 1; // start cpu_wait_time, 

  enQueue(ready_queue, findThread(everything_queue, t));
  if(running_thread == NULL && !isEmpty(ready_queue)) {
    running_thread = ready_queue->front->data->threadd;
    ready_queue->front->data->last_tick = sim_time() + 1;
    deQueue(ready_queue);
    sim_dispatch(running_thread); // dispatch next ready thread 
  }
}

void io_starting(thread_t *t) { 
  printf("IOstart\n");
  // calculate io_wait_time
  struct threadInfo* info = findThread(everything_queue, t);
  info->io_wait_time = sim_time() - info->last_tick -1; 
  printf("IOstart\n");
}

stats_t *stats() { // called once 
  int thread_count = everything_queue->count; 
  int total_turnaround_time = 0;
  int total_wait_time = 0;
  stats_t *stats = malloc(sizeof(stats_t));
  stats->tstats = malloc(sizeof(stats_t)*thread_count);

  printf("Total number of threads in stats: %d\n", thread_count);

  // individual threads
  while(!isEmpty(everything_queue)) {
    struct threadInfo* info = everything_queue->front->data;
    stats->tstats[info->threadd->tid-1].tid = info->threadd->tid;
    stats->tstats[info->threadd->tid-1].turnaround_time = info->turnaround_time; 
    stats->tstats[info->threadd->tid-1].waiting_time = info->cpu_wait_time + info->io_wait_time; 

    printf("CPUWT: %d\n", info->cpu_wait_time);
    printf("IOWT: %d\n",info->io_wait_time);

    total_turnaround_time += info->turnaround_time;
    total_wait_time += info->cpu_wait_time + info->io_wait_time;
    deQueue(everything_queue);
  }

  // all threads, calculate means
  stats->thread_count = thread_count; 
  stats->turnaround_time = total_turnaround_time / thread_count; 
  stats->waiting_time = total_wait_time / thread_count; 
  return stats; 
}