#include "cartman.h"
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>

// pthread_mutex_t mutex[5]; 
// sem_t limit_Junctions; 
sem_t semm[5];
pthread_t threadd; // did not work when i put this line into arrive()

typedef struct curr_cart {
    unsigned int cart; 
    enum track track;
    enum junction junction;
} curr_cart;

// enum track { Red, Green, Blue, Yellow, Black };
// enum junction {A, B, C, D, E};

void* cart_arrived(void* arg) {
    curr_cart* info = (curr_cart*) arg;

    int left = info->track;
    int right = (left + 1) % 5;

    // if track is odd, switch left right
    if(info->track % 2 != 0 ) {
        right = info->track;
        left = (right+1) % 5;
    }
    // sem_wait(&limit_Junctions);
    
    // pthread_mutex_lock(&mutex[left]);
    sem_wait(&semm[left]);
    reserve(info->cart, left);

    // pthread_mutex_lock(&mutex[right]);
    sem_wait(&semm[right]);
    reserve(info->cart, right);
    
    // junctions are now reserved, free to cross 
    cross(info->cart, info->track, info->junction); 
    return NULL;
}
/*
* I noticed that Deadlock passes a good majority of the  time, 
* but it occasionally fails to pass ./cartman -d 
*
*/
void arrive(unsigned int cart, enum track track, enum junction junction) 
{
    struct curr_cart *info = malloc(sizeof(struct curr_cart));
    info->cart = cart; 
    info->track = track; 
    info->junction = junction;

    // create new thread for cart, 1 for each junction 
    pthread_create(&threadd, NULL, cart_arrived, info);
}

void depart(unsigned int cart, enum track track, enum junction junction) 
{
    // release junction 
    // unlock semaphore
    int left = track;
    int right = (left + 1) % 5;

    release(cart, right);
    // pthread_mutex_unlock(&mutex[right]);
    sem_post(&semm[right]);
    release(cart, left);
    // pthread_mutex_unlock(&mutex[left]);
    sem_post(&semm[left]);

    // sem_post(&limit_Junctions);
}

void cartman() 
{
    // I referenced this site for the use of counting semaphore
    // https://medium.com/swlh/the-dining-philosophers-problem-solution-in-c-90e2593f64e8

    // sem_init(&limit_Junctions, 0, 2); // should be  4, but doesn't work with 4 
    for(int i = 0; i < 5; ++i) 
        sem_init(&semm[i], 0, 1);
        // pthread_mutex_init(&mutex[i], NULL);
}

/*
* I noticed that Deadlock passes a good majority of the  time, 
* but it occasionally fails to pass ./cartman -d 
* Random sometimes does not work either
*/