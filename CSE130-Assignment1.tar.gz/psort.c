/************************************************************************
 * 
 * CSE130 Winter 2021 Assignment 1
 *  
 * POSIX Shared Memory Multi-Process Merge Sort
 * 
 * Copyright (C) 2020-2021 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 *
 ************************************************************************/

#include "merge.h"
#include <fcntl.h> 
#include <sys/mman.h>
#include <sys/stat.h> 
#include <sys/wait.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


/* LEFT index and RIGHT index of the sub-array of ARR[] to be sorted */
void singleProcessMergeSort(int arr[], int left, int right) 
{
  if (left < right) {
    int middle = (left+right)/2;
    singleProcessMergeSort(arr, left, middle); 
    singleProcessMergeSort(arr, middle+1, right); 
    merge(arr, left, middle, right); 
  } 
}

/* 
 * This function stub needs to be completed
 */
void multiProcessMergeSort(int arr[], int left, int right) 
{
  // Your code goes here
  if (left < right) {
    int middle = (left+right) / 2;
    int half = middle - left + 1; // return half of num of arr elem

    const int SIZE = sizeof(&arr); // size of the array address
    const char *shm_name = "shm"; 
    int shm_fd = shm_open(shm_name, O_CREAT | O_RDWR, 0666);
    ftruncate(shm_fd, SIZE); 

    // put array into shared memory
    int *ptr; 
    ptr = mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

    // for(int i = 0; i <= middle; ++i) { 
    //   ptr[i] = arr[i]; 
    // }
    memcpy(ptr, arr, half * sizeof(int));

    switch(fork()) {
      case -1:
        exit(-1); 
      case 0: //child process  
        singleProcessMergeSort(ptr, left, middle); // sort to shared memory 
        shm_unlink(shm_name); 
        exit(0); 
      default: //parent process 
        singleProcessMergeSort(arr, middle+1, right); 
        wait(NULL); // block parent process until any of its children has finished. 
        
        // put array into shared memory
        // for(int i = left; i <= middle; ++i) {
        //   arr[i] = ptr[i]; 
        // }
        memcpy(arr, ptr, half * sizeof(int));

        merge(arr, left, middle, right); 
        shm_unlink(shm_name);
        munmap(ptr, SIZE); 
        
        close(0);
    }
  } 
}
