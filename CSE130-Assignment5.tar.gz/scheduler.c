/**
 * See scheduler.h for function details. All are callbacks; i.e. the simulator 
 * calls you when something interesting happens.
 */
#include <stdlib.h>
#include <stdio.h>
#include "simulator.h"
#include "scheduler.h"

typedef enum {false, true} bool;
struct threadInfo { 
  thread_t *threadd; // holds thread 
  int tick_count; 

  int first_tick; // first tick of the cpu wait time 
  int last_tick; // last tick on cpu 

  int arrival_time; // time thread arrived 
  int exit_time; // time thread exited the program 
  
  int turnaround_time; // turnaround time
  int cpu_wait_time; // time it takes to get back on cpu from io and arrival 
  int io_wait_time; // time it takes to start io
};

// Queue Implementation based on https://www.geeksforgeeks.org/queue-linked-list-implementation/
// I took createNode(), enqueue(), dequeue() from the implementation
struct Node { 
  struct threadInfo *data; 
  struct Node *next; 
};

struct Node* createNode(struct threadInfo* info){ // constructor 
  struct Node *n = (struct Node*)malloc(sizeof(struct Node)); // allocates mem
  n->data = info;
  n->next = NULL; 
  return n; 
}

struct Queue { 
  struct Node *front;
  struct Node *end; 
  int count;
};

void enQueue(struct Queue *q, struct threadInfo* info ) { 
  struct Node *n = createNode(info); 
  // info->tick_count = 0;
  q->count++;
  if(q->end == NULL) {
    q->front = n = q->end = n; // c
    return;
  } 
  q->end->next = n;
  q->end = q->end->next;
}
// I made this function 
void printQ(struct Queue *q) {
  struct Node *temp = q->front; 
  printf("Q: ");
  while(temp != NULL) {
    printf("%d ",temp->data->threadd->tid);
    temp = temp->next; 
  }
  printf("\n");
}
// I made this isEmpty function 
bool isEmpty(struct Queue* q) {
  if(q->front == NULL) 
    return true;
  else 
    return false; 
}

void deQueue(struct Queue* q) { 
  if(q->front != NULL) {
    q->count--;
    struct Node* n = q->front; 
    q->front = q->front->next;
    if(q->front == NULL)
      q->end = NULL;
    free(n); 
  }
  return;
}

// This Bubble Sort Implementation based on https://www.geeksforgeeks.org/c-program-bubble-sort-linked-list/
void sortQueue(struct Queue *q) {
  if(isEmpty(q)) return; 
  struct Node * left = NULL;
  int swapped; 
  do {
    swapped = 0; 
    struct Node * right = q->front; 
    while(right->next != left) {

      if(right->data->threadd->priority > right->next->data->threadd->priority) {
        struct threadInfo * temp = right->data; 
        right->data = right->next->data; 
        right->next->data = temp; 
        swapped = 1; 
      }
      right = right->next; 
    }
    left = right; 
  } while(swapped);
}

// Queue Implementation based on https://www.geeksforgeeks.org/queue-linked-list-implementation/
// Queue Implementation end

// I made this find thread function
struct threadInfo* findThread(struct Queue* q, thread_t *t) {
  // printf("Hit\n");
  struct Node* iterator = q->front; 
  if(iterator == NULL){
    return NULL;
  }
  while(iterator->data->threadd->tid != t->tid){
    iterator = iterator->next;
  }
  return iterator->data; 
}

struct Queue *ready_queue; // threads ready to go on cpu 
struct Queue *everything_queue; // all threads 

thread_t* running_thread = NULL;
int quantumm = 0; 
enum algorithm algo;

void scheduler(enum algorithm algorithm, unsigned int quantum) { 
  ready_queue = (struct Queue*)malloc(sizeof(struct Queue));
  everything_queue = (struct Queue*)malloc(sizeof(struct Queue));
  quantumm = quantum; 
  algo = algorithm;
}

void sim_tick() {}

void sim_ready() { 
  if (algo == ROUND_ROBIN) {
    if(running_thread == NULL) { // if nothing on cpu 
      if(!isEmpty(ready_queue)) {
        // ready_queue->front->data->cpu_wait_time += sim_time() - ready_queue->front->data->first_tick;
        ready_queue->front->data->last_tick = sim_time(); // used for io_wait_time
        running_thread = ready_queue->front->data->threadd;
        findThread(everything_queue, running_thread)->tick_count++;
        deQueue(ready_queue); 
        sim_dispatch(running_thread);
      } 
    }
    else {
      if (findThread(everything_queue, running_thread)->tick_count != 0 && 
        (findThread(everything_queue, running_thread)->tick_count % quantumm == 0)) {
        if(!isEmpty(ready_queue)){
          ready_queue->front->data->cpu_wait_time += sim_time() - ready_queue->front->data->first_tick;
          ready_queue->front->data->last_tick = sim_time(); // used for io_wait_time
          findThread(everything_queue, running_thread)->first_tick = sim_time(); 

          enQueue(ready_queue, findThread(everything_queue, running_thread));
          running_thread = ready_queue->front->data->threadd;
          printQ(ready_queue);
          deQueue(ready_queue); 
          sim_dispatch(running_thread);
        }
      }
      findThread(everything_queue, running_thread)->tick_count++;
    }
  }
  if (algo == NON_PREEMPTIVE_PRIORITY) {
    sortQueue(ready_queue);
    if(running_thread == NULL) {
      // printQ(ready_queue);
      if(!isEmpty(ready_queue)) { // run highes priority thread 
        printQ(ready_queue);
        running_thread = ready_queue->front->data->threadd;
        ready_queue->front->data->last_tick = sim_time() + 1;
        deQueue(ready_queue); 
        sim_dispatch(running_thread); 
      }
    }
  }
  if (algo == PREEMPTIVE_PRIORITY) {
    sortQueue(ready_queue);
    if(!isEmpty(ready_queue) && running_thread != NULL){
      if(ready_queue->front->data->threadd->priority < findThread(everything_queue, running_thread)->threadd->priority){
        printf("here\n");
        ready_queue->front->data->last_tick = sim_time(); 
        findThread(everything_queue, running_thread)->first_tick = sim_time();
        enQueue(ready_queue, findThread(everything_queue, running_thread));
        sortQueue(ready_queue);

        running_thread = ready_queue->front->data->threadd;
        deQueue(ready_queue);
        sim_dispatch(running_thread);
      }
    }
    else {
      if(running_thread == NULL) {
        if(!isEmpty(ready_queue)) { // run highest priority thread 
          sortQueue(ready_queue);
          printQ(ready_queue);
          running_thread = ready_queue->front->data->threadd;
          ready_queue->front->data->last_tick = sim_time();

          deQueue(ready_queue); 
          sim_dispatch(running_thread); 
        }
      }
    }
  } 
}

void sys_exec(thread_t *t) { 
  // printf("exec\n");
  struct threadInfo *info = (struct threadInfo*)malloc(sizeof(struct threadInfo));
  info->tick_count = 0;  
  info->arrival_time = sim_time();
  info->exit_time = 0; 
  info->first_tick = 0;
  info->last_tick = 0;
  info->exit_time = 0; // end tick, use sim_time() at exit() ? 
  info->turnaround_time = 0;
  info->cpu_wait_time = 0; // time it takes to get on cpu|
  info->io_wait_time = 0; // time it takes to get on io

  info->threadd = t; 
  info->first_tick = sim_time();
  enQueue(everything_queue, info); 
  enQueue(ready_queue, info); 

}
  

void sys_read(thread_t *t) { 
  printf("read\n");
  if(algo == NON_PREEMPTIVE_PRIORITY || algo == PREEMPTIVE_PRIORITY) {
    sortQueue(ready_queue);
    findThread(everything_queue, running_thread)->last_tick = sim_time();
    running_thread = NULL;
    if(!isEmpty(ready_queue)) {
      sortQueue(ready_queue);
      ready_queue->front->data->last_tick = sim_time() + 1;
      struct threadInfo * info =  ready_queue->front->data;
      info->cpu_wait_time += sim_time() - info->first_tick + 1;
    }
  }
  else {
    findThread(everything_queue, running_thread)->last_tick = sim_time();
    running_thread = NULL;
    if(!isEmpty(ready_queue)) {
      ready_queue->front->data->last_tick = sim_time() + 1;
      struct threadInfo * info =  ready_queue->front->data;
      info->cpu_wait_time += sim_time() - info->first_tick + 1;
    }
  }
}

void sys_write(thread_t *t) { 
  // printf("write\n");
  if(algo == NON_PREEMPTIVE_PRIORITY || algo == PREEMPTIVE_PRIORITY) {
    sortQueue(ready_queue);
    findThread(everything_queue, running_thread)->last_tick = sim_time();
    running_thread = NULL;
    if(!isEmpty(ready_queue)) {
      sortQueue(ready_queue);
      ready_queue->front->data->last_tick = sim_time() + 1;
      struct threadInfo * info =  ready_queue->front->data;
      info->cpu_wait_time += sim_time() - info->first_tick + 1;
    }
  }
  else {
    findThread(everything_queue, running_thread)->last_tick = sim_time();
    running_thread = NULL;
    if(!isEmpty(ready_queue)) {
      ready_queue->front->data->last_tick = sim_time() + 1;
      struct threadInfo * info =  ready_queue->front->data;
      info->cpu_wait_time += sim_time() - info->first_tick + 1;
    }
  }
}

void sys_exit(thread_t *t) { 
  // printf("exit\n");

  if(algo == NON_PREEMPTIVE_PRIORITY || algo == PREEMPTIVE_PRIORITY) {
    sortQueue(ready_queue);
    struct threadInfo *info = findThread(everything_queue, running_thread);
    info->exit_time = sim_time(); 
    info->turnaround_time = info->exit_time - info->arrival_time + 1; 
    running_thread = NULL;
    if(running_thread == NULL && !isEmpty(ready_queue)) {
      sortQueue(ready_queue);
      ready_queue->front->data->cpu_wait_time += sim_time() - ready_queue->front->data->first_tick + 1;
      ready_queue->front->data->tick_count = 0;
    }
  }
  else {
    struct threadInfo *info = findThread(everything_queue, running_thread);
    info->exit_time = sim_time(); 
    info->tick_count = 0;
    info->turnaround_time = info->exit_time - info->arrival_time + 1; 
    running_thread = NULL;
    if(running_thread == NULL && !isEmpty(ready_queue)) {
      ready_queue->front->data->cpu_wait_time += sim_time() - ready_queue->front->data->first_tick + 1;
      ready_queue->front->data->tick_count = 0;
    }
  }
}

void io_complete(thread_t *t) { 
  // printf("IOcomplete\n");
  if(algo == NON_PREEMPTIVE_PRIORITY || algo == PREEMPTIVE_PRIORITY) {
    sortQueue(ready_queue);
    struct threadInfo *info = findThread(everything_queue, t);

    info->first_tick = sim_time() + 1; // start cpu_wait_time, 
    info->tick_count = 0;
    
    enQueue(ready_queue, findThread(everything_queue, t));
    sortQueue(ready_queue);
    if(running_thread == NULL && !isEmpty(ready_queue)) {
      sortQueue(ready_queue);
      ready_queue->front->data->last_tick = sim_time() + 1;
      ready_queue->front->data->tick_count = 0; 
    }
  }
  else {
    struct threadInfo *info = findThread(everything_queue, t);
    info->first_tick = sim_time() + 1; // start cpu_wait_time, 
    info->tick_count = 0;
    enQueue(ready_queue, findThread(everything_queue, t));
    if(running_thread == NULL && !isEmpty(ready_queue)) {
      ready_queue->front->data->last_tick = sim_time() + 1;
      ready_queue->front->data->tick_count = 0; 
    }
  }
}

void io_starting(thread_t *t) { 
  // printf("IOstart\n");
  // calculate io_wait_time
  struct threadInfo* info = findThread(everything_queue, t);
  info->io_wait_time = sim_time() - info->last_tick - 1; 
  // printf("IOstart\n");
}

stats_t *stats() { 
  int thread_count = everything_queue->count; 
  int total_turnaround_time = 0;
  int total_wait_time = 0;
  stats_t *stats = malloc(sizeof(stats_t));
  stats->tstats = malloc(sizeof(stats_t)*thread_count);

  printf("Total number of threads in stats: %d\n", thread_count);

  // individual threads
  while(!isEmpty(everything_queue)) {
    struct threadInfo* info = everything_queue->front->data;
    stats->tstats[info->threadd->tid-1].tid = info->threadd->tid;
    stats->tstats[info->threadd->tid-1].turnaround_time = info->turnaround_time; 
    stats->tstats[info->threadd->tid-1].waiting_time = info->cpu_wait_time + info->io_wait_time; 

    printf("CPUWT: %d\n", info->cpu_wait_time);
    printf("IOWT: %d\n",info->io_wait_time);

    total_turnaround_time += info->turnaround_time;
    total_wait_time += info->cpu_wait_time + info->io_wait_time;
    deQueue(everything_queue);
  }

  // all threads, calculate means
  stats->thread_count = thread_count; 
  stats->turnaround_time = total_turnaround_time / thread_count; 
  stats->waiting_time = total_wait_time / thread_count; 
  return stats;
}