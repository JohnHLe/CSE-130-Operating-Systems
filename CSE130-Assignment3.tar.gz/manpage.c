
/*********************************************************************
 *
 * Copyright (C) 2020-2021 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 *
 ***********************************************************************/

#include "manpage.h"
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>

sem_t order[7];

void *printer(void* arg) { 
  int pid = getParagraphId();
  sem_wait(&order[pid]); 
  showParagraph();  
  if(pid != 6)
    sem_post(&order[pid+1]); // unlock
  pthread_exit(NULL);
  return NULL;
}
/*
 * See manpage.h for details.
 *
 * As supplied, shows random single messages.
 */
void manpage() 
{
  // initialize semaphores
  sem_init(&order[0], 0, 1);
  for(int i = 1; i < 7; ++i) 
    sem_init(&order[i], 0, 0);

  // create threads 
  pthread_t thread_arr[7]; 
  for(int i = 0; i < 7; ++i) {
    int test = pthread_create(&thread_arr[i], NULL, printer, NULL);
    if(test == -1) {
      exit(-1);
    }
  }
  // wait 
  for(int i = 0; i < 7; ++i) {
    pthread_join(thread_arr[i], NULL);
  }
  for(int i = 0; i < 7; ++i)
    sem_destroy(&order[i]);
}
